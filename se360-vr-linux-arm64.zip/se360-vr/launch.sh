#!/bin/bash
# Space Explorers 360 — native Steam Frame launcher (Vulkan + SteamVR).
# FrameDrop/Steam-Devkit friendly: everything resolves relative to this
# script, so the wrapper folder works from any install location.
APPDIR="$(cd "$(dirname "$0")" && pwd)"
export XR_RUNTIME_JSON="$HOME/.config/openxr/1/active_runtime.json"
export LD_LIBRARY_PATH="/opt/steamvr/lib/linuxarm64:$APPDIR/lib:${LD_LIBRARY_PATH:-}"
cd "$APPDIR"
exec ./se360_vr --spv ./spv --assets ./assets >> se360.log 2>&1
