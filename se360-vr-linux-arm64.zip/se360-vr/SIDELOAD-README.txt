Space Explorers 360 — Steam Frame (native Vulkan + SteamVR)
============================================================

Installed as a Steam library entry. Launch
"Space Explorers 360" from Steam.

* PLAYING: start the PC server (start_server.bat in the companion
  server folder, http://<pc-ip>:8080) on the same LAN. Without it,
  only the bundled Felix & Paul CDN rows play (server rows show OFFLINE).
* CONTROLS: menu button opens the menu; D-pad/ABXY/thumbstick moves,
  A selects; A with the menu closed toggles pause.
* LOG: se360.log next to launch.sh.
